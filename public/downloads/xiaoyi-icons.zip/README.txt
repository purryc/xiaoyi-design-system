Xiaoyi icons: hand-authored 24x24 SVG research reconstruction.
Default stroke 1.65, round joins and caps. See manifest for source and provenance per icon.
Not an official Huawei icon distribution.
小艺图标：24×24 手绘 SVG 研究复刻。默认笔画 1.65，圆端点与圆连接。每枚图标的来源见 manifest；非华为官方图标分发。
